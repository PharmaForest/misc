filename PBC957E2 list;

 %put NOTE- ;
 %put NOTE: Loading package misc, version 0.0.8, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-27T17:40:28; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(misc) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  PBC957E2(packagemetadata.sas) / nosource2; 

 data _null_;                                    
  call symputX("packageRequiredErrors", 0, "L"); 
 run;                                            
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(%str(
 options nonotes nosource ;                          
 options ls=max ps=max locale=en_US ;                
 /* temporary redirect log */                        
 filename _stinit_ TEMP ;                            
 proc printto log = _stinit_ ; run ;                 
 /* print out setinit */                             
 proc setinit ; run ;                                
 proc printto ; run ;                                
 options ps=min ;                                    
 data _null_ ;                                       
   /* loadup checklist of required SAS components */ 
   if _n_ = 1 then                                   
     do ;                                            
       length req $ 256 ;                            
       declare hash R() ;                            
       _N_ = R.defineKey("req") ;                    
       _N_ = R.defineDone() ;                        
       declare hiter iR("R") ;                       
         do req = %bquote(
"BASE SAS SOFTWARE"
) ; 
          _N_ = R.add(key:req,data:req) ;            
         end ;                                       
     end ;                                           
                                                     
   /* read in output from proc setinit */            
   infile _stinit_ end=eof ;                         
   input ;                                           
                                                     
   /* if component is in setinit remove it from checklist */ 
   if _infile_ =: "---" then                         
     do ;                                            
       req = upcase(substr(_infile_, 4, 64)) ;       
       if R.find(key:req) = 0 then                   
         do ;                                        
           _N_ = R.remove() ;                        
         end ;                                       
     end ;                                           
                                                     
   /* if checklist is not null rise error */         
   if eof and R.num_items > 0 then                   
     do ;                                            
       put "WARNING- ###########################################" ; 
       put "WARNING:  The following SAS components are missing! " ; 
       call symputX("packageRequiredErrors", 0, "L") ;              
       do while(iR.next() = 0) ;                                    
         put "WARNING-   " req ;                                    
       end ;                                                        
       put "WARNING:  The package may NOT WORK as expected      " ; 
       put "WARNING:  or even result with ERRORS!               " ; 
       put "WARNING- ###########################################" ; 
       put ;                                         
     end ;                                           
 run ;                                               
 filename _stinit_ clear ;                           
 options notes source ;                              
 )))*;                                               
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 options &temp_noNotes_etc.;                        
data _null_; 
  call symputX('cherryPick_FCMP', exist('work.miscfcmp'), 'L'); 
run; 
 
%if (%str(*)=%superq(cherryPick)) or (swapc in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type function from the file "swapc.sas" will be included <<;
  %include PBC957E2(_function.swapc.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.miscfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.miscfcmp);)
))
 
%if (%str(*)=%superq(cherryPick)) or (swapc_vec in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type function from the file "swapc_vec.sas" will be included <<;
  %include PBC957E2(_function.swapc_vec.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (swapn in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type function from the file "swapn.sas" will be included <<;
  %include PBC957E2(_function.swapn.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (swapn_vec in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type function from the file "swapn_vec.sas" will be included <<;
  %include PBC957E2(_function.swapn_vec.sas) / nosource2;
  %let cherryPick_FCMP = %eval(&cherryPick_FCMP. + 1);
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (color_swatch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "color_swatch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(color_swatch)=1, NOTE# Macro color_swatch exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.color_swatch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (derive_epoch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "derive_epoch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(derive_epoch)=1, NOTE# Macro derive_epoch exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.derive_epoch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (line_swatch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "line_swatch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(line_swatch)=1, NOTE# Macro line_swatch exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.line_swatch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (minimize_charlen in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "minimize_charlen.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(minimize_charlen)=1, NOTE# Macro minimize_charlen exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.minimize_charlen.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (rounddec in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "rounddec.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(rounddec)=1, NOTE# Macro rounddec exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.rounddec.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (roundsig in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "roundsig.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(roundsig)=1, NOTE# Macro roundsig exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.roundsig.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (symbol_swatch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "symbol_swatch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(symbol_swatch)=1, NOTE# Macro symbol_swatch exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.symbol_swatch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (view_swatch in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "view_swatch.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(view_swatch)=1, NOTE# Macro view_swatch exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.view_swatch.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (xpt2sas in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "xpt2sas.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(xpt2sas)=1, NOTE# Macro xpt2sas exist. It will be overwritten by the macro from the misc package, ));
  %include PBC957E2(_macro.xpt2sas.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;                                   
length CASLUDF $ 32767;                        
dtCASLudf = datetime();                        
CASLUDF =                                      
    '%macro miscCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for misc package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `miscCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20260727.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                           
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'
 !! "  filename PBC957E2 &ZIP. '&path./misc.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename PBC957E2 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

%if 0 = &cherryPick_FCMP. %then %do;
options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.miscfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%end;
data _null_;
run;
data _null_;
run;
%if (%str(*)=%superq(cherryPick)) %then %do;
proc fcmp outlib = work.miscfcmp.packagemeta ; 
 function miscMETA(meta $) $ 32767;
  m = char(upcase(meta),1);
   if m = 'V' then return(strip("0.0.8"));
   if m = 'D' then return(strip("2026-10-27T17:40:28"));
   if m = 'A' then return(strip("[Yutaka Morioka],[Hiroki Yamanobe],[Ryo Nakaya],[Saikrishnareddy Yengannagari]"));
   if m = 'M' then return(strip("[Yutaka Morioka],[Hiroki Yamanobe],[Ryo Nakaya]"));
   if m = 'T' then return(strip("misc package to place miscellaneous macros"));
   if m = 'E' then return(strip("UTF8"));
   if m = 'L' then return(strip("2026-10-27T17:40:28"));
   if m = 'S' then return(strip("""BASE SAS SOFTWARE"""));
  return(" ");
 endfunc;
quit;
%sysfunc(ifc(0<
  %sysfunc(findw((%sysfunc(getoption(cmplib)))
                ,work.miscfcmp,"'( )'",RIO))
,,%str(options APPEND=(cmplib = work.miscfcmp);)
))
%macro miscMETA(meta)/parmbuff;
%if %superq(meta) = %then %return;
%do;%qsysfunc(strip(%qsysfunc(miscMETA&syspbuff.)))%end;
%mend;


%end;
%put NOTE- ;
%put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));

%if (%str(*)=%superq(cherryPick)) %then %do; 
 %let temp_noNotes_etc=%sysfunc(getoption(NOTES));
 options noNotes;
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#misc(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'misc(0.0.8)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'misc(0.0.8)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO: [SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'misc(0.0.8)', 'G');                            
      put / 'INFO: [SYSLOADEDPACKAGES] misc(0.0.8)';                                     
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
 options &temp_noNotes_etc.;
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package misc, version 0.0.8, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

