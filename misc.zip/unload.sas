filename PBC957E2 list;
%put NOTE: Unloading package misc, version 0.0.8, license MIT;
%put NOTE- *** START ***;
proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'MISCMETA'
   ,'MISCIML'
   ,'MISCCASLUDF'
   %put NOTE- Element of type macros generated from the file "color_swatch.sas" will be deleted;
   %put NOTE- ;
   ,"COLOR_SWATCH                                                    "
   %put NOTE- Element of type macros generated from the file "derive_epoch.sas" will be deleted;
   %put NOTE- ;
   ,"DERIVE_EPOCH                                                    "
   %put NOTE- Element of type macros generated from the file "line_swatch.sas" will be deleted;
   %put NOTE- ;
   ,"LINE_SWATCH                                                     "
   %put NOTE- Element of type macros generated from the file "minimize_charlen.sas" will be deleted;
   %put NOTE- ;
   ,"MINIMIZE_CHARLEN                                                "
   %put NOTE- Element of type macros generated from the file "rounddec.sas" will be deleted;
   %put NOTE- ;
   ,"ROUNDDEC                                                        "
   %put NOTE- Element of type macros generated from the file "roundsig.sas" will be deleted;
   %put NOTE- ;
   ,"ROUNDSIG                                                        "
   %put NOTE- Element of type macros generated from the file "symbol_swatch.sas" will be deleted;
   %put NOTE- ;
   ,"SYMBOL_SWATCH                                                   "
   %put NOTE- Element of type macros generated from the file "view_swatch.sas" will be deleted;
   %put NOTE- ;
   ,"VIEW_SWATCH                                                     "
   %put NOTE- Element of type macros generated from the file "xpt2sas.sas" will be deleted;
   %put NOTE- ;
   ,"XPT2SAS                                                         "
  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"
  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'MISCFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.miscfcmp.package;
%put NOTE- Element of type functions generated from the file "swapc.sas" will be deleted;
%put NOTE- ;
deletefunc swapc ;
%put NOTE- Element of type functions generated from the file "swapc_vec.sas" will be deleted;
%put NOTE- ;
deletefunc swapc_vec ;
%put NOTE- Element of type functions generated from the file "swapn.sas" will be deleted;
%put NOTE- ;
deletefunc swapn ;
%put NOTE- Element of type functions generated from the file "swapn_vec.sas" will be deleted;
%put NOTE- ;
deletefunc swapn_vec ;
quit;

proc fcmp outlib = work.miscfcmp.packagemeta;
deletefunc miscMETA;
quit;

options cmplib = (%unquote(%sysfunc(tranwrd(
%sysfunc(lowcase(%sysfunc(getoption(cmplib))))
,%str(work.miscfcmp), %str() ))));
options cmplib = (%unquote(%sysfunc(compress(
%sysfunc(getoption(cmplib))
,%str(()) ))));
%put; %put NOTE:[CMPLIB] %sysfunc(getoption(cmplib));
proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                         
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#misc(0.0.8)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#misc(0.0.8)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  
%put NOTE: Unloading package misc, version 0.0.8, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;
/* unload.sas end */
