filename PBC957E2 list;
 %put NOTE- ;
 %put NOTE: Preview of the misc package, version 0.0.8, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-27T17:52:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;
%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include PBC957E2(packagemetadata.sas) / nosource2; 
data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile PBC957E2(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         
data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
functions/functions/functions/swapc.sas/swapc/'swapc()'
functions/functions/functions/swapc_vec.sas/swapc_vec/'swapc_vec()'
functions/functions/functions/swapn.sas/swapn/'swapn()'
functions/functions/functions/swapn_vec.sas/swapn_vec/'swapn_vec()'
macros/macros/macros/color_swatch.sas/color_swatch/'%color_swatch()'
macros/macros/macros/derive_epoch.sas/derive_epoch/'%derive_epoch()'
macros/macros/macros/line_swatch.sas/line_swatch/'%line_swatch()'
macros/macros/macros/minimize_charlen.sas/minimize_charlen/'%minimize_charlen()'
macros/macros/macros/rounddec.sas/rounddec/'%rounddec()'
macros/macros/macros/roundsig.sas/roundsig/'%roundsig()'
macros/macros/macros/symbol_swatch.sas/symbol_swatch/'%symbol_swatch()'
macros/macros/macros/view_swatch.sas/view_swatch/'%view_swatch()'
macros/macros/macros/xpt2sas.sas/xpt2sas/'%xpt2sas()'
;;;;
run;
data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile PBC957E2(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 
%put NOTE: Preview of the misc package, version 0.0.8, license MIT;
%put NOTE- *** END ***;
/* preview.sas end */
